import { getStore } from '@netlify/blobs';
export default async () => {
  try {
    const store = getStore('skyhop-scores');
    const list = await store.list({prefix:'player:'});
    const players = await Promise.all(list.blobs.slice(0,1000).map(x => store.get(x.key,{type:'json'})));
    const result = players.filter(Boolean).map(x=>({nick:x.nick,best:x.best})).sort((a,b)=>b.best-a.best).slice(0,100);
    return Response.json(result,{headers:{'Access-Control-Allow-Origin':'*','Cache-Control':'no-store'}});
  } catch(e) { console.error(e); return Response.json({error:'Storage unavailable'},{status:503,headers:{'Access-Control-Allow-Origin':'*'}}); }
};
