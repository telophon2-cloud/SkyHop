import { getStore } from '@netlify/blobs';
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'};
export default async request => {
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
  if(request.method!=='POST')return Response.json({error:'Method not allowed'},{status:405,headers:cors});
  try {
    const body=await request.json();
    const nick=String(body.nick||'').trim(), token=String(body.token||'');
    const score=body.score;
    if(!/^[\p{L}\p{N}_ -]{2,20}$/u.test(nick)||!/^[a-f0-9]{32}$/i.test(token)||!Number.isSafeInteger(score)||score<0||score>1000000)
      return Response.json({error:'Invalid data'},{status:400,headers:cors});
    const store=getStore('skyhop-scores');
    const key='player:'+token.toLowerCase();
    const old=await store.get(key,{type:'json'});
    const best=Math.max(old?.best||0,score);
    await store.setJSON(key,{nick,best});
    return Response.json({ok:true,best},{headers:cors});
  } catch(e) {console.error(e);return Response.json({error:'Storage unavailable'},{status:503,headers:cors});}
};
